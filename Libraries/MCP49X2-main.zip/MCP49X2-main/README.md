# MCP49X2 Digital-to-Analog Converter (DAC)
Arduino library for MCP4902, MCP4912 & MCP4922 Digital-to-Analog Converter Series from Microchip Inc.
